﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

// Author : Aaron Koh Hsien Loong//
// Purpose of code : To develop the method for the addScores Class  //
// Date : 08/08/16//
// Known bugs: //

namespace studentScores
{
    public partial class frmAddNewStudent : Form
    {
        ClassRoll aClassRoll;
        Student newStudent;
        string name = "";
        string strScore = "";
        int newScore;
        List<int> newScores = new List<int>();

        public frmAddNewStudent()
        {
            InitializeComponent();

        }

        private void frmAddNewStudent_Load(object sender, EventArgs e)
        {
            aClassRoll = this.Tag as ClassRoll;
            //newStudent = new Student("Henry");
            
        }

        private void btnAddScore_Click(object sender, EventArgs e)
        {
            try
            {   
                newScore = Convert.ToInt32(txtScore.Text.Trim());
                if (newScore < 0 || newScore > 100)
                {
                    MessageBox.Show("It must be a score between 0 to 100");
                }
                else
                {
                    newScores.Add(newScore);
                    strScore += txtScore.Text.Trim() + " ";
                    txtScores.Text = strScore;
                    txtScore.Text = "";
                    txtScore.Focus();
                }
            }
            catch
            {
                MessageBox.Show("Please Insert a Number");
            }
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            name = txtName.Text;
            if (name != "")
            {
                if (txtScores.Text == "")
                {
                    newStudent = new Student(name);
                    aClassRoll.addStudent(newStudent);
                }
                else
                {
                    newStudent = new Student(name, newScores);
                    aClassRoll.addStudent(newStudent);
                }
                this.Close();
            }
            else
            {
                MessageBox.Show("Please Insert a name before Adding!");
            }
            //aClassRoll.addStudent(newStudent);
            this.Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnClearScores_Click(object sender, EventArgs e)
        {
            txtScores.Text = "";
            strScore = "";
            newScores.Clear();
            txtScore.Focus();
        }
    }
}
