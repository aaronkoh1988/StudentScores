﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

// Author : Aaron Koh Hsien Loong//
// Purpose of code : a constructor to develop the student and its scores  //
// Date : 08/08/16 //
// Known bugs: //

namespace studentScores
{
    class Student
    {
        private string studentName {set; get;}
        private List<int> scores {set; get;}

        public Student()
        {
            scores = new List<int>();
        }

        public Student(string aName)
        {
            studentName = aName;
            scores = new List<int>();
        }

        public Student(string aName, int score)
        {
            studentName = aName;
            scores = new List<int>();
            scores.Add(score);
        }

        public Student(string aName, List<int> scorelist)
        {
            studentName = aName;
            scores = scorelist;
        }

        public override string ToString()
        {
            string strScore = "";
            foreach(int score in scores)
            {
                strScore += " |" + score.ToString();
            }
            return studentName + strScore;
        }

        public int getTotal()
        {
            int sum = 0;
            foreach (int score in scores)
            {
                sum += score;
            }
            return sum;
        }

        public int getCount()
        {
            return scores.Count();
        }

        public float getAverage()
        {
            if (getCount() != 0)
            {
                return getTotal() / getCount();
            }
            else
            {
                return 0;
            }

        }

        public List<int> getScores()
        {
            return this.scores;
        }

        public void addScore(int newScore)
        {
            scores.Add(newScore);
        }

        public void removeScore(int newScore)
        {
            scores.Remove(newScore);
        }

        public int getAScore(int index)
        {
            int[] aScore = scores.ToArray();
            return aScore[index];
        }

        public string getCurrentStudentName()
        {
            return this.studentName;
        }


    }
}
