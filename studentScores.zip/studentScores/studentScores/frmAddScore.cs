﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace studentScores
{
    public partial class frmAddScore : Form
    {
        
        int newScore;
        Student currStudent; //create new student

        public frmAddScore()
        {
            InitializeComponent();
            
        }

        private void frmAddScore_Load(object sender, EventArgs e)
        {
            currStudent = this.Tag as Student;//tag the current student
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            newScore = Convert.ToInt16(txtAddScore.Text.Trim());
            currStudent.addScore(newScore); //this will addScore into Current Student
            
            this.Close();
        }

        
    }
}
