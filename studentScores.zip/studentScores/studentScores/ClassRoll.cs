﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

// Author : Aaron Koh Hsien Loong//
// Purpose of code : a classRoll Class to develop a student list  //
// Date : 11/08/16 //
// Known bugs: //

namespace studentScores
{
    class ClassRoll
    {
        List<Student> classRoll = null;

        public ClassRoll()
        {
            classRoll = new List<Student>();
            
        }

        public void addStudent(Student newStudent)
        {
            classRoll.Add(newStudent);
        }

        public void removeStudent(Student curStudent)
        {
            classRoll.Remove(curStudent);
        }

        public List<Student> getStudentList()
        {
            return classRoll;
        }

        public Student getStudent(int index)
        {
                Student[] aStudent = classRoll.ToArray();
                return aStudent[index];
        }
        
    }
}
