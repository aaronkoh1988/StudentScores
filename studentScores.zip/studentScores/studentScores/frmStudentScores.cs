﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

// Author : Aaron Koh Hsien Loong//
// Purpose of code : To develop the method for the studentScores Class  //
// Date : 08/08/16 //
// Known bugs: //


namespace studentScores
{
    public partial class StudentScores : Form
    {
        ClassRoll aClassRoll = null;

        public StudentScores()
        {
            InitializeComponent();
        }

        private void StudentScores_Load(object sender, EventArgs e)
        {
            aClassRoll = new ClassRoll();
           

            Student student1 = new Student("Joel Murach", new List<int>() { 80, 90, 99 });
            Student student2 = new Student("Aaron Koh", new List<int>() { 60,80,99 });
            Student student3 = new Student("Anne Boehm", new List<int>() {100,100,100});

            aClassRoll.addStudent(student1);
            aClassRoll.addStudent(student2);
            aClassRoll.addStudent(student3);

            upDateList();
            lstStudent.SelectedIndex = 0;

        }

        private void upDateList()
        {
            lstStudent.Items.Clear();
            List<Student> studentList = aClassRoll.getStudentList();
            foreach (Student aStudent in studentList)
            {
                lstStudent.Items.Add(aStudent);
            }
        }


        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void lstStudent_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                
                Student aStudent = aClassRoll.getStudent(lstStudent.SelectedIndex);
                
                txtScoreTotal.Text = aStudent.getTotal().ToString();
                txtScoreCount.Text = aStudent.getCount().ToString();
                txtAverage.Text = aStudent.getAverage().ToString();
            }
            catch
            {
                MessageBox.Show("Please select a Student in the List!");
            }
        }

        private void btnAddNew_Click(object sender, EventArgs e)
        {
            Form frmNewStudent = new frmAddNewStudent();
            frmNewStudent.Tag = aClassRoll;
            frmNewStudent.ShowDialog();
            upDateList();

        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                Form frmUpdate = new frmUpdateStudentScores();
                Student curStudent = aClassRoll.getStudent(lstStudent.SelectedIndex);
                frmUpdate.Tag = curStudent;
                frmUpdate.ShowDialog();
                upDateList();
            }
            catch
            {
                MessageBox.Show("Please select a Student in the List!");
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                Student curStudent = aClassRoll.getStudent(lstStudent.SelectedIndex);
                aClassRoll.removeStudent(curStudent);
                upDateList();
            }
            catch
            {
                MessageBox.Show("Please select a Student in the List!");
            }
        }
    }
}
