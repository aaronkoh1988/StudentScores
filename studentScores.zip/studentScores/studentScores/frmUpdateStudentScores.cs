﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

// Author : Aaron Koh Hsien Loong//
// Purpose of code : To develop the method to update Student Scores Class  //
// Date : 08/08/16//
// Known bugs: //

namespace studentScores
{
    public partial class frmUpdateStudentScores : Form
    {

        Student currStudent;
        List<int> currScores = null;
        

        public frmUpdateStudentScores()
        {
            currScores = new List<int>(currStudent.getScores());
            InitializeComponent();
        }

        private void frmUpdateStudentScores_Load(object sender, EventArgs e)
        {
            
            currStudent = this.Tag as Student;
            txtStudentName.Text = currStudent.getCurrentStudentName();
            
            updateScores();
        }

        private void updateScores()
        {
            lstStudentScore.Items.Clear();
            currScores = currStudent.getScores();
            foreach (int score in currScores)
            {
                lstStudentScore.Items.Add(score);
            }
        }


        private void btnAdd_Click(object sender, EventArgs e)
        {
            Form frmAddScore = new frmAddScore();
            frmAddScore.Tag = currStudent;
            frmAddScore.ShowDialog();
            updateScores();
        }
        
        private void btnUpdate_Click(object sender, EventArgs e)
        {
            Form frmUpdateScore = new frmUpdateScore();
            frmUpdateScore.Tag = currStudent;
            frmUpdateScore.ShowDialog();
            //updateScores();
        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            //updateScores();
        }

        private void btnClearScores_Click(object sender, EventArgs e)
        {
            lstStudentScore.Items.Clear();
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            //currScores.Clear();
            
            this.Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

       

    }
}
